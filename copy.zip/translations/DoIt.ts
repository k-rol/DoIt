<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>GetterRequest</name>
    <message>
        <location filename="../src/GetterRequest.cpp" line="100"/>
        <source>Error: %1 status: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/GetterRequest.cpp" line="108"/>
        <source>Unable to retrieve request headers</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="../assets/main.qml" line="9"/>
        <source>GoPro App</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
